"""Example application modules."""
